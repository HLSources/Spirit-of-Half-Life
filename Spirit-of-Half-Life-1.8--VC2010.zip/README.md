Spirit-of-Half-Life-1.8--VC2010
===============================

Spirit of Half-Life 1.8 RB Toolkit for Microsoft Visual Studio 2010